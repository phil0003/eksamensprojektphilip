const htmlEditor = document.getElementById("html-editor");
const cssEditor = document.getElementById("css-editor");
const output = document.getElementById("output");

function updateOutput() {
  const htmlContent = htmlEditor.value;
  const cssContent = cssEditor.value;

  // Create an iframe and append it to the output div
  const iframe = document.createElement("iframe");
  output.innerHTML = "";
  output.appendChild(iframe);

  // Write the HTML and CSS content to the iframe
  const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
  iframeDoc.open();
  iframeDoc.write(`<html><head><style>${cssContent}</style></head><body>${htmlContent}</body></html>`);
  iframeDoc.close();
}

htmlEditor.addEventListener("input", updateOutput);
cssEditor.addEventListener("input", updateOutput);

// Update output on page load
window.addEventListener("DOMContentLoaded", updateOutput);
